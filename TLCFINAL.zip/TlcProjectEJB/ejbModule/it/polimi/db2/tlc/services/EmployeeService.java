package it.polimi.db2.tlc.services;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.NonUniqueResultException;

import it.polimi.db2.tlc.entities.*;
import it.polimi.db2.tlc.exceptions.*;
import java.util.List;

@Stateless
public class EmployeeService {
	
	@PersistenceContext(unitName = "TlcProjectEJB")
	private EntityManager em;

	public EmployeeService() {
		
	}
	
	public Employee checkCredentials(String usrn, String pwd) throws CredentialsException, NonUniqueResultException {
		List<Employee> empList = null;
		try {
			empList = em.createNamedQuery("Employee.checkCredentials", Employee.class).setParameter(1, usrn).setParameter(2, pwd)
					.getResultList();
		} catch (PersistenceException e) {
			throw new CredentialsException("Could not verify credentals");
		}
		if (empList.isEmpty())
			return null;
		else if (empList.size() == 1)
			return empList.get(0);
		throw new NonUniqueResultException("More than one Employee registered with same credentials");

	}
	
	public void createProfile(Employee e) {
		em.persist(e);

	}

}
