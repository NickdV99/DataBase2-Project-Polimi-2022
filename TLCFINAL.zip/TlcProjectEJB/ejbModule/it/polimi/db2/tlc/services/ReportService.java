package it.polimi.db2.tlc.services;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import it.polimi.db2.tlc.entities.*;
import it.polimi.db2.tlc.exceptions.*;

@Stateless
public class ReportService {
	@PersistenceContext(unitName = "TlcProjectEJB")
	private EntityManager em;
	
	public ReportService() {
		
	}
	
	public List<ReportPurchasesPackage> findAllReportPurchasesPackage() throws ServiceException{
		
		List<ReportPurchasesPackage> purchasedPackages = null;
		
		try {
			purchasedPackages = em.createNamedQuery("ReportPurchasesPackage.findAll", ReportPurchasesPackage.class).getResultList();

		} catch (PersistenceException e) {
			throw new ServiceException("Cannot load services");

		}
		return purchasedPackages;
	}
	
	public List<ReportPurchasePackageValidityPeriod> findAllReportPurchasePackageValidityPeriod() throws ServiceException{
		
		List<ReportPurchasePackageValidityPeriod> purchasedPackagesVP = null;
		
		try {
			purchasedPackagesVP = em.createNamedQuery("ReportPurchasePackageValidityPeriod.findAll", ReportPurchasePackageValidityPeriod.class).getResultList();

		} catch (PersistenceException e) {
			throw new ServiceException("Cannot load services");

		}
		return purchasedPackagesVP;
	}
	
	public List<ReportAvegareOptionalPackage> findAllReportAvegareOptionalPackage() throws ServiceException{
		
		List<ReportAvegareOptionalPackage> averageOptional = null;
		
		try {
			averageOptional = em.createNamedQuery("ReportAvegareOptionalPackage.findAll", ReportAvegareOptionalPackage.class).getResultList();

		} catch (PersistenceException e) {
			throw new ServiceException("Cannot load services");

		}
		return averageOptional;
	}
	
	public List<ReportTotalSalesPackage> findAllReportTotalSalesPackage() throws ServiceException{
		
		List<ReportTotalSalesPackage> totalSales = null;
		
		try {
			totalSales = em.createNamedQuery("ReportTotalSalesPackage.findAll", ReportTotalSalesPackage.class).getResultList();

		} catch (PersistenceException e) {
			throw new ServiceException("Cannot load services");

		}
		return totalSales;
	}
	
	public List<ReportBestSellerOptional> findAllReportBestSellerOptional() throws ServiceException{
		
		List<ReportBestSellerOptional> bestSellerOptional = null;
		
		try {
			bestSellerOptional = em.createNamedQuery("ReportBestSellerOptional.findAll", ReportBestSellerOptional.class).getResultList();

		} catch (PersistenceException e) {
			throw new ServiceException("Cannot load services");

		}
		return bestSellerOptional;
	}
	
	public List<ReportInsolventUser> findAllReportInsolventUsers() throws ServiceException{
		
		List<ReportInsolventUser> insolventUsers = null;
		
		try {
			insolventUsers = em.createNamedQuery("ReportInsolventUser.findAll", ReportInsolventUser.class).getResultList();

		} catch (PersistenceException e) {
			throw new ServiceException("Cannot load services");

		}
		return insolventUsers;
	}
	public List<ReportSuspendedOrder> findAllReportSuspendedOrders() throws ServiceException{
		
		List<ReportSuspendedOrder> suspendedOrders = null;
		
		try {
			suspendedOrders = em.createNamedQuery("ReportSuspendedOrder.findAll", ReportSuspendedOrder.class).getResultList();

		} catch (PersistenceException e) {
			throw new ServiceException("Cannot load services");

		}
		return suspendedOrders;
	}
	
	public List<Alert> findAllAlerts() throws ServiceException{
		
		List<Alert> alerts = null;
		
		try {
			alerts = em.createNamedQuery("Alert.findAll", Alert.class).getResultList();

		} catch (PersistenceException e) {
			throw new ServiceException("Cannot load services");

		}
		return alerts;
	}

}
