package it.polimi.db2.tlc.services;

import java.util.List;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.NonUniqueResultException;

import it.polimi.db2.tlc.exceptions.*;
import it.polimi.db2.tlc.entities.*;

@Stateless
public class OrderService {
	@PersistenceContext(unitName = "TlcProjectEJB")
	private EntityManager em;

	public OrderService() {
	}

	public List<Ordertable> findOrdertablesByConsumer(int consumerId) {
		Consumer consumer = em.find(Consumer.class, consumerId);
		List<Ordertable> ordertables = consumer.getOrdertables();
		return ordertables;
	}
	
	public List<Ordertable> findOrdertablesByConsumerRefresh(int consumerId) {
		Consumer consumer = em.find(Consumer.class, consumerId);
		em.refresh(consumer);
		List<Ordertable> ordertables = consumer.getOrdertables();
		return ordertables;
	}

	public Ordertable findOrdertableById(int orderId) {
		Ordertable ordertable = em.find(Ordertable.class, orderId);
		return ordertable;
	}
	

	public Ordertable createOrdertable(ServicePackage servicePackage,Consumer consumer,Date dateOfCreation, int totalPrice, Date dateOfSubscription, int valid, int idValidityPeriod) {
		
		Ordertable ordertable = new Ordertable(servicePackage, consumer, dateOfCreation, totalPrice, dateOfSubscription, valid, idValidityPeriod);
		
		System.out.println("Ordine Creato");
		int casualValidBit = this.casualValidBit();
		int counter = consumer.getCounter();
		System.out.println("Counter consumer: " + counter);
		if (casualValidBit==1) {
			ordertable.setValid((int) 1);
			} else {ordertable.setValid((int) 0);
			counter = counter + 1;
			consumer.setCounter(counter);
			}
		System.out.println("Valid Bit settato a "+ ordertable.getValid());
		System.out.println("Counter consumer: " + counter);
		
		em.persist(ordertable); 
		em.merge(consumer);
		
		System.out.println("Database aggiornato");
		
		return ordertable;

	}
	
	public Ordertable createOrdertableWOptional(int idOrdertable, ServicePackage servicePackage,Consumer consumer,Date dateOfCreation, int totalPrice, Date dateOfSubscription, int valid, int idValidityPeriod,List<Optional> optionals) {
		
		Ordertable ordertable = new Ordertable(servicePackage, consumer, dateOfCreation, totalPrice, dateOfSubscription, valid, idValidityPeriod, optionals);
		System.out.println("Id ordertable scelto: " + idOrdertable);
		ordertable.setId(idOrdertable);
		System.out.println("Id ordertable settato a : " + ordertable.getId());
		System.out.println("Ordine Creato");
		int casualValidBit = this.casualValidBit();
		int counter = consumer.getCounter();
		System.out.println("Counter consumer: " + counter);
		if (casualValidBit==1) {
			ordertable.setValid((int) 1);
			} else {ordertable.setValid((int) 0);
			counter = counter + 1;
			consumer.setCounter(counter);
			}
		System.out.println("Valid Bit settato a "+ ordertable.getValid());
		System.out.println("Counter consumer: " + counter);
		
		em.persist(ordertable); 
		em.merge(consumer);
		
		System.out.println("Database aggiornato");
		
		return ordertable;

	}
	
	public Ordertable updateOrdertable(Ordertable rejectOrdertable, int consumerId) {
		
		System.out.println("Aggiorno ordine con id" + rejectOrdertable.getId());
		
		Consumer consumer = em.find(Consumer.class, consumerId);
		
		int casualValidBit = this.casualValidBit();
		int counter = consumer.getCounter();
		System.out.println("Counter consumer: " + (int)counter);
		
		
		if (casualValidBit==1) {
			rejectOrdertable.setValid((int) 1);
			if(counter > 0) {
			counter = counter -1;
			consumer.setCounter(counter);
			}
			} else {
				rejectOrdertable.setValid((int) 0);
				counter = counter + 1; 
				consumer.setCounter(counter);
			}
		System.out.println("Counter consumer: " + (int)counter);
		
		System.out.println("Valid Bit settato a "+ rejectOrdertable.getValid());
		
		em.merge(rejectOrdertable); 
		em.merge(consumer);
		
		System.out.println("Database aggiornato");
		
		return rejectOrdertable;

	}
	
	public int casualValidBit() {
		
		int casualValidBit = (int) (Math.random() * 2);
		System.out.println("Numero casuale: " + casualValidBit);		
		return casualValidBit;
		
	}
	
}
