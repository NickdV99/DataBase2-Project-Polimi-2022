package it.polimi.db2.tlc.services;

import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import it.polimi.db2.tlc.entities.*;
import it.polimi.db2.tlc.exceptions.*;

@Stateless
public class OptionalService {
	@PersistenceContext(unitName = "TlcProjectEJB")
	private EntityManager em;

	public OptionalService() {
	}

	public List<Optional> findAllOptionals() throws PackageException{
		
		List<Optional> optionals = null;
		
		try {
			optionals = em.createNamedQuery("Optional.findAll", Optional.class).getResultList();

		} catch (PersistenceException e) {
			throw new PackageException("Cannot load packages");

		}
		return optionals;
	}
	
	public Optional findOptionaleById(int optionalId) {
		Optional optional = em.find(Optional.class, optionalId);
		return optional;
	}
	
	public void createOptional(Optional optional) {
		
		em.persist(optional); 

	}
	
	
}