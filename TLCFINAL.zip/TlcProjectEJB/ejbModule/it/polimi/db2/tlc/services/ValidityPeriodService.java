package it.polimi.db2.tlc.services;

import java.util.List;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.NonUniqueResultException;

import it.polimi.db2.tlc.exceptions.*;
import it.polimi.db2.tlc.entities.*;

@Stateless
public class ValidityPeriodService {
	@PersistenceContext(unitName = "TlcProjectEJB")
	private EntityManager em;
	
	public ValidityPeriodService() {
	}	

	public List<ValidityPeriod> findByServicePackage(int packageId) {
		return em.createNamedQuery("ValidityPeriod.findByServicePackage", ValidityPeriod.class).setParameter("packageId", packageId)
				.getResultList();
	}
	
	public ValidityPeriod findValidityPeriodById(int periodId) {
		ValidityPeriod validityPeriod = em.find(ValidityPeriod.class, periodId);
		return validityPeriod;
	}
	
	public ValidityPeriod createValidityPeriod(ServicePackage servicePackage, int months, int price) {
		
		ValidityPeriod validityPeriod = new ValidityPeriod(servicePackage, months, price);
		
		System.out.println("Validity Period Creato");
		
		//em.persist(validityPeriod); 
		
		System.out.println("Database aggiornato col nuovo ValidityPeriod");
		
		return validityPeriod;

	}
	
	public ValidityPeriod createValidityPeriodWId(int id, ServicePackage servicePackage, int months, int price) {
		
		ValidityPeriod validityPeriod = new ValidityPeriod(id, servicePackage, months, price);
		
		System.out.println("Validity Period Creato");
		
		em.persist(validityPeriod); 

		
		System.out.println("Database aggiornato col nuovo ValidityPeriod");
		
		return validityPeriod;

	}
	
	
}
