package it.polimi.db2.tlc.services;

import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import it.polimi.db2.tlc.entities.*;
import it.polimi.db2.tlc.exceptions.*;

@Stateless
public class PackageService {
	@PersistenceContext(unitName = "TlcProjectEJB")
	private EntityManager em;

	public PackageService() {
	}

	public List<ServicePackage> findAllPackages() throws PackageException{
		
		List<ServicePackage> servicePackages = null;
		
		try {
			servicePackages = em.createNamedQuery("ServicePackage.findAll", ServicePackage.class).getResultList();

		} catch (PersistenceException e) {
			throw new PackageException("Cannot load packages");

		}
		return servicePackages;
	}
	
	public ServicePackage findServicePackageById(int packageId) {
		ServicePackage servicePackage = em.find(ServicePackage.class, packageId);
		return servicePackage;
	}
	
	public ServicePackage findDefault() {
		ServicePackage found = null;
		List<ServicePackage> results = em.createNamedQuery("ServicePackage.findAll", ServicePackage.class).getResultList();
		if (results.size() > 0)
			found = results.get(0);
		return found;
	}

	
	public void createServicePackage(int id, String packageName,List<Service> services, List<ValidityPeriod> validityPeriods) {
		
		ServicePackage servicePackage = new ServicePackage(id, packageName, services, validityPeriods);
		
		System.out.println("ServicePackage Creato");
		
		em.merge(servicePackage); 
		
		System.out.println("Database aggiornato");


	}
	
	public void createServicePackageNoId(String packageName,List<Service> services, List<ValidityPeriod> validityPeriods) {
		
		ServicePackage servicePackage = new ServicePackage(packageName, services, validityPeriods);
		
		System.out.println("ServicePackage Creato");
		
		em.persist(servicePackage); 
		
		System.out.println("Database aggiornato");


	}
	
	public void createServicePackageId(int id) {
		
		ServicePackage servicePackage = new ServicePackage(id);
		
		System.out.println("ServicePackage Creato");
		
		em.persist(servicePackage); 
		
		System.out.println("Database aggiornato");


	}
	
	
}
