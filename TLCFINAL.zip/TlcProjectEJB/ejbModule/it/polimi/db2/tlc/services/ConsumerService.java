package it.polimi.db2.tlc.services;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.NonUniqueResultException;

import it.polimi.db2.tlc.entities.*;
import it.polimi.db2.tlc.exceptions.*;
import java.util.List;

@Stateless
public class ConsumerService {
	@PersistenceContext(unitName = "TlcProjectEJB")
	private EntityManager em;

	public ConsumerService() {
	}
	
	
	public Consumer checkCredentials(String usrn, String pwd) throws CredentialsException, NonUniqueResultException {
		List<Consumer> csrList = null;
		try {
			csrList = em.createNamedQuery("Consumer.checkCredentials", Consumer.class).setParameter(1, usrn).setParameter(2, pwd)
					.getResultList();
		} catch (PersistenceException e) {
			throw new CredentialsException("Could not verify credentals");
		}
		if (csrList.isEmpty())
			return null;
		else if (csrList.size() == 1)
			return csrList.get(0);
		throw new NonUniqueResultException("More than one Consumer registered with same credentials");

	}
	
	public void createProfile(Consumer c) {
					em.persist(c);
	
	}
}
