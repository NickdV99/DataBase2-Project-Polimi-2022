package it.polimi.db2.tlc.services;

import java.util.List;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.NonUniqueResultException;

import it.polimi.db2.tlc.exceptions.*;
import it.polimi.db2.tlc.entities.*;

@Stateless
public class ServiceService {
	@PersistenceContext(unitName = "TlcProjectEJB")
	private EntityManager em;

	public ServiceService() {
	}

	public Service findServiceById(int serviceId) {
		Service service = em.find(Service.class, serviceId);
		return service;
	}

	public List<Service> findAllServices() throws PackageException{
		
		List<Service> services = null;
		
		try {
			services = em.createNamedQuery("Service.findAll", Service.class).getResultList();

		} catch (PersistenceException e) {
			throw new PackageException("Cannot load packages");

		}
		return services;
	}
	
}