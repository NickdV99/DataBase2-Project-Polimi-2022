package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the service database table.
 * 
 */
@Entity
@Table(name="service")
@NamedQuery(name="Service.findAll", query="SELECT s FROM Service s")
public class Service implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name="fee_extra_giga")
	private String feeExtraGiga;

	@Column(name="fee_extra_min")
	private String feeExtraMin;

	@Column(name="fee_extra_sms")
	private String feeExtraSms;

	private String giga;

	private String minute;

	private String sms;

	private String type;

	//bi-directional many-to-many association to ServicePackage
	@ManyToMany(mappedBy="services")
	private List<ServicePackage> servicePackages;

	public Service() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFeeExtraGiga() {
		return this.feeExtraGiga;
	}

	public void setFeeExtraGiga(String feeExtraGiga) {
		this.feeExtraGiga = feeExtraGiga;
	}

	public String getFeeExtraMin() {
		return this.feeExtraMin;
	}

	public void setFeeExtraMin(String feeExtraMin) {
		this.feeExtraMin = feeExtraMin;
	}

	public String getFeeExtraSms() {
		return this.feeExtraSms;
	}

	public void setFeeExtraSms(String feeExtraSms) {
		this.feeExtraSms = feeExtraSms;
	}

	public String getGiga() {
		return this.giga;
	}

	public void setGiga(String giga) {
		this.giga = giga;
	}

	public String getMinute() {
		return this.minute;
	}

	public void setMinute(String minute) {
		this.minute = minute;
	}

	public String getSms() {
		return this.sms;
	}

	public void setSms(String sms) {
		this.sms = sms;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<ServicePackage> getServicePackages() {
		return this.servicePackages;
	}

	public void setServicePackages(List<ServicePackage> servicePackages) {
		this.servicePackages = servicePackages;
	}

}