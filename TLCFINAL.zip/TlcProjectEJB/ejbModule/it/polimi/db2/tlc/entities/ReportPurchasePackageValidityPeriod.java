package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the report_purchase_package_validity_period database table.
 * 
 */
@Entity
@Table(name="report_purchase_package_validity_period")
@NamedQuery(name="ReportPurchasePackageValidityPeriod.findAll", query="SELECT r FROM ReportPurchasePackageValidityPeriod r")
public class ReportPurchasePackageValidityPeriod implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ReportPurchasePackageValidityPeriodPK id;

	@Column(name="total_purchase")
	private int totalPurchase;

	//bi-directional many-to-one association to ServicePackage
	@ManyToOne
	@JoinColumn(name="id_package")
	private ServicePackage servicePackage;

	//bi-directional many-to-one association to ValidityPeriod
	@ManyToOne
	@JoinColumn(name="id_validity_period")
	private ValidityPeriod validityPeriod;

	public ReportPurchasePackageValidityPeriod() {
	}

	public ReportPurchasePackageValidityPeriodPK getId() {
		return this.id;
	}

	public void setId(ReportPurchasePackageValidityPeriodPK id) {
		this.id = id;
	}

	public int getTotalPurchase() {
		return this.totalPurchase;
	}

	public void setTotalPurchase(int totalPurchase) {
		this.totalPurchase = totalPurchase;
	}

	public ServicePackage getServicePackage() {
		return this.servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

	public ValidityPeriod getValidityPeriod() {
		return this.validityPeriod;
	}

	public void setValidityPeriod(ValidityPeriod validityPeriod) {
		this.validityPeriod = validityPeriod;
	}

}