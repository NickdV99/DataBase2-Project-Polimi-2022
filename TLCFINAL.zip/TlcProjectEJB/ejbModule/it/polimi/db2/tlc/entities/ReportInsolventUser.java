package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the report_insolvent_user database table.
 * 
 */
@Entity
@Table(name="report_insolvent_user")
@NamedQuery(name="ReportInsolventUser.findAll", query="SELECT r FROM ReportInsolventUser r")
public class ReportInsolventUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="consumer_id")
	private int consumerId;

	public ReportInsolventUser() {
	}

	public int getConsumerId() {
		return this.consumerId;
	}

	public void setConsumerId(int consumerId) {
		this.consumerId = consumerId;
	}

}