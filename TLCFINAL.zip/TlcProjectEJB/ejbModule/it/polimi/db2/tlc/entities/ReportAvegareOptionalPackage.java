package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the report_avegare_optional_package database table.
 * 
 */
@Entity
@Table(name="report_avegare_optional_package")
@NamedQuery(name="ReportAvegareOptionalPackage.findAll", query="SELECT r FROM ReportAvegareOptionalPackage r")
public class ReportAvegareOptionalPackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_package")
	private int idPackage;

	@Column(name="average_optional")
	private float averageOptional;

	@Column(name="name_service_package")
	private String nameServicePackage;

	//bi-directional one-to-one association to ServicePackage
	@OneToOne
	@PrimaryKeyJoinColumn(name="id_package")
	private ServicePackage servicePackage;

	public ReportAvegareOptionalPackage() {
	}

	public int getIdPackage() {
		return this.idPackage;
	}

	public void setIdPackage(int idPackage) {
		this.idPackage = idPackage;
	}

	public float getAverageOptional() {
		return this.averageOptional;
	}

	public void setAverageOptional(float averageOptional) {
		this.averageOptional = averageOptional;
	}

	public String getNameServicePackage() {
		return this.nameServicePackage;
	}

	public void setNameServicePackage(String nameServicePackage) {
		this.nameServicePackage = nameServicePackage;
	}

	public ServicePackage getServicePackage() {
		return this.servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

}