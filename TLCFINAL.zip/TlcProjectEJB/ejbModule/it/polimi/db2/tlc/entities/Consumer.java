package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the consumer database table.
 * 
 */
@Entity
@Table(name="consumer")
@NamedQuery(name="Consumer.findAll", query="SELECT c FROM Consumer c")
@NamedQuery(name="Consumer.checkCredentials", query="SELECT c FROM Consumer c WHERE c.username = ?1 and c.password = ?2")
public class Consumer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private int counter;

	private String email;

	private byte insolvent;

	private String password;

	private String username;

	//bi-directional one-to-one association to Alert
	@OneToOne(mappedBy="consumer")
	private Alert alert;

	//bi-directional many-to-one association to Ordertable
	@OneToMany(mappedBy="consumer")
	private List<Ordertable> ordertables;

	public Consumer() {
	}
	
	public Consumer(String username, String password) {
	    
	    this.username = username; 
	    this.password = password; 
	    
	  }

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCounter() {
		return this.counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public byte getInsolvent() {
		return this.insolvent;
	}

	public void setInsolvent(byte insolvent) {
		this.insolvent = insolvent;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Alert getAlert() {
		return this.alert;
	}

	public void setAlert(Alert alert) {
		this.alert = alert;
	}

	public List<Ordertable> getOrdertables() {
		return this.ordertables;
	}

	public void setOrdertables(List<Ordertable> ordertables) {
		this.ordertables = ordertables;
	}

	public Ordertable addOrdertable(Ordertable ordertable) {
		getOrdertables().add(ordertable);
		ordertable.setConsumer(this);

		return ordertable;
	}

	public Ordertable removeOrdertable(Ordertable ordertable) {
		getOrdertables().remove(ordertable);
		ordertable.setConsumer(null);

		return ordertable;
	}

}