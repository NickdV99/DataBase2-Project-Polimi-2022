package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the report_best_seller_optional database table.
 * 
 */
@Entity
@Table(name="report_best_seller_optional")
@NamedQuery(name="ReportBestSellerOptional.findAll", query="SELECT r FROM ReportBestSellerOptional r")
public class ReportBestSellerOptional implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_optional")
	private int idOptional;

	@Column(name="total_sales_optional")
	private int totalSalesOptional;

	public ReportBestSellerOptional() {
	}

	public int getIdOptional() {
		return this.idOptional;
	}

	public void setIdOptional(int idOptional) {
		this.idOptional = idOptional;
	}

	public int getTotalSalesOptional() {
		return this.totalSalesOptional;
	}

	public void setTotalSalesOptional(int totalSalesOptional) {
		this.totalSalesOptional = totalSalesOptional;
	}

}