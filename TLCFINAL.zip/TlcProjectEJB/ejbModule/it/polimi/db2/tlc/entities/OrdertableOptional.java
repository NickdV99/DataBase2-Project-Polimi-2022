package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ordertable_optional database table.
 * 
 */
@Entity
@Table(name="ordertable_optional")
@NamedQuery(name="OrdertableOptional.findAll", query="SELECT o FROM OrdertableOptional o")
public class OrdertableOptional implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrdertableOptionalPK id;

	//bi-directional many-to-one association to Optional
	@ManyToOne
	@JoinColumn(name="id_optional")
	private Optional optional;

	//bi-directional many-to-one association to Ordertable
	@ManyToOne
	@JoinColumn(name="id_ordertable")
	private Ordertable ordertable;

	public OrdertableOptional() {
	}

	public OrdertableOptionalPK getId() {
		return this.id;
	}

	public void setId(OrdertableOptionalPK id) {
		this.id = id;
	}

	public Optional getOptional() {
		return this.optional;
	}

	public void setOptional(Optional optional) {
		this.optional = optional;
	}

	public Ordertable getOrdertable() {
		return this.ordertable;
	}

	public void setOrdertable(Ordertable ordertable) {
		this.ordertable = ordertable;
	}

}