package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the report_total_sales_package database table.
 * 
 */
@Entity
@Table(name="report_total_sales_package")
@NamedQuery(name="ReportTotalSalesPackage.findAll", query="SELECT r FROM ReportTotalSalesPackage r")
public class ReportTotalSalesPackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_package")
	private int idPackage;

	@Column(name="value_package")
	private int valuePackage;

	public ReportTotalSalesPackage() {
	}

	public int getIdPackage() {
		return this.idPackage;
	}

	public void setIdPackage(int idPackage) {
		this.idPackage = idPackage;
	}

	public int getValuePackage() {
		return this.valuePackage;
	}

	public void setValuePackage(int valuePackage) {
		this.valuePackage = valuePackage;
	}

}