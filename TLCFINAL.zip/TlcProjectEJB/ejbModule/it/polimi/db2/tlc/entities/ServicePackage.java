package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the service_package database table.
 * 
 */
@Entity
@Table(name="service_package")
@NamedQuery(name="ServicePackage.findAll", query="SELECT s FROM ServicePackage s")
public class ServicePackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String name;

	//bi-directional many-to-one association to Ordertable
	@OneToMany(mappedBy="servicePackage")
	private List<Ordertable> ordertables;

	//bi-directional one-to-one association to ReportAvegareOptionalPackage
	@OneToOne(mappedBy="servicePackage")
	private ReportAvegareOptionalPackage reportAvegareOptionalPackage;

	//bi-directional many-to-one association to ReportPurchasePackageValidityPeriod
	@OneToMany(mappedBy="servicePackage")
	private List<ReportPurchasePackageValidityPeriod> reportPurchasePackageValidityPeriods;

	//bi-directional one-to-one association to ReportPurchasesPackage
	@OneToOne(mappedBy="servicePackage")
	private ReportPurchasesPackage reportPurchasesPackage;

	//bi-directional many-to-many association to Optional
	@ManyToMany
	@JoinTable(
		name="service_package_optional"
		, joinColumns={
			@JoinColumn(name="id_service_package")
			}
		, inverseJoinColumns={
			@JoinColumn(name="id_optional")
			}
		)
	private List<Optional> optionals;

	//bi-directional many-to-many association to Service
	@ManyToMany
	@JoinTable(
		name="service_package_service"
		, joinColumns={
			@JoinColumn(name="id_service_package")
			}
		, inverseJoinColumns={
			@JoinColumn(name="id_service")
			}
		)
	private List<Service> services;

	//bi-directional many-to-one association to ValidityPeriod
	@OneToMany(mappedBy="servicePackage")
	private List<ValidityPeriod> validityPeriods;

	public ServicePackage() {
	}
	
	public ServicePackage(int id) {
	    this.id = id;  
	  }
	
	public ServicePackage(int id, String packageName,List<Service> services, List<ValidityPeriod> validityPeriods) {
	    this.id = id;
	    this.name = packageName; 
	    this.services = services; 
	    this.validityPeriods = validityPeriods;
	    
	  }

	  public ServicePackage(String packageName,List<Service> services, List<ValidityPeriod> validityPeriods) {
	    
	    this.name = packageName; 
	    this.services = services; 
	    this.validityPeriods = validityPeriods;
	    
	  }

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Ordertable> getOrdertables() {
		return this.ordertables;
	}

	public void setOrdertables(List<Ordertable> ordertables) {
		this.ordertables = ordertables;
	}

	public Ordertable addOrdertable(Ordertable ordertable) {
		getOrdertables().add(ordertable);
		ordertable.setServicePackage(this);

		return ordertable;
	}

	public Ordertable removeOrdertable(Ordertable ordertable) {
		getOrdertables().remove(ordertable);
		ordertable.setServicePackage(null);

		return ordertable;
	}

	public ReportAvegareOptionalPackage getReportAvegareOptionalPackage() {
		return this.reportAvegareOptionalPackage;
	}

	public void setReportAvegareOptionalPackage(ReportAvegareOptionalPackage reportAvegareOptionalPackage) {
		this.reportAvegareOptionalPackage = reportAvegareOptionalPackage;
	}

	public List<ReportPurchasePackageValidityPeriod> getReportPurchasePackageValidityPeriods() {
		return this.reportPurchasePackageValidityPeriods;
	}

	public void setReportPurchasePackageValidityPeriods(List<ReportPurchasePackageValidityPeriod> reportPurchasePackageValidityPeriods) {
		this.reportPurchasePackageValidityPeriods = reportPurchasePackageValidityPeriods;
	}

	public ReportPurchasePackageValidityPeriod addReportPurchasePackageValidityPeriod(ReportPurchasePackageValidityPeriod reportPurchasePackageValidityPeriod) {
		getReportPurchasePackageValidityPeriods().add(reportPurchasePackageValidityPeriod);
		reportPurchasePackageValidityPeriod.setServicePackage(this);

		return reportPurchasePackageValidityPeriod;
	}

	public ReportPurchasePackageValidityPeriod removeReportPurchasePackageValidityPeriod(ReportPurchasePackageValidityPeriod reportPurchasePackageValidityPeriod) {
		getReportPurchasePackageValidityPeriods().remove(reportPurchasePackageValidityPeriod);
		reportPurchasePackageValidityPeriod.setServicePackage(null);

		return reportPurchasePackageValidityPeriod;
	}

	public ReportPurchasesPackage getReportPurchasesPackage() {
		return this.reportPurchasesPackage;
	}

	public void setReportPurchasesPackage(ReportPurchasesPackage reportPurchasesPackage) {
		this.reportPurchasesPackage = reportPurchasesPackage;
	}

	public List<Optional> getOptionals() {
		return this.optionals;
	}

	public void setOptionals(List<Optional> optionals) {
		this.optionals = optionals;
	}

	public List<Service> getServices() {
		return this.services;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}

	public List<ValidityPeriod> getValidityPeriods() {
		return this.validityPeriods;
	}

	public void setValidityPeriods(List<ValidityPeriod> validityPeriods) {
		this.validityPeriods = validityPeriods;
	}

	public ValidityPeriod addValidityPeriod(ValidityPeriod validityPeriod) {
		getValidityPeriods().add(validityPeriod);
		validityPeriod.setServicePackage(this);

		return validityPeriod;
	}

	public ValidityPeriod removeValidityPeriod(ValidityPeriod validityPeriod) {
		getValidityPeriods().remove(validityPeriod);
		validityPeriod.setServicePackage(null);

		return validityPeriod;
	}

}