package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the report_suspended_order database table.
 * 
 */
@Entity
@Table(name="report_suspended_order")
@NamedQuery(name="ReportSuspendedOrder.findAll", query="SELECT r FROM ReportSuspendedOrder r")
public class ReportSuspendedOrder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_order")
	private int idOrder;

	public ReportSuspendedOrder() {
	}

	public int getIdOrder() {
		return this.idOrder;
	}

	public void setIdOrder(int idOrder) {
		this.idOrder = idOrder;
	}

}