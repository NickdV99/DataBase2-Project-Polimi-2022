package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the ordertable database table.
 * 
 */
@Entity
@Table(name="ordertable")
@NamedQuery(name="Ordertable.findAll", query="SELECT o FROM Ordertable o")
public class Ordertable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="date_of_creation")
	private Date dateOfCreation;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="date_of_subscription")
	private Date dateOfSubscription;

	@Column(name="id_validity_period")
	private int idValidityPeriod;

	@Column(name="total_price")
	private int totalPrice;

	private int valid;

	//bi-directional many-to-one association to Consumer
	@ManyToOne
	@JoinColumn(name="id_consumer")
	private Consumer consumer;

	//bi-directional many-to-many association to Optional
	@ManyToMany
	@JoinTable(
		name="ordertable_optional"
		, joinColumns={
			@JoinColumn(name="id_ordertable")
			}
		, inverseJoinColumns={
			@JoinColumn(name="id_optional")
			}
		)
	private List<Optional> optionals;

	//bi-directional many-to-one association to ServicePackage
	@ManyToOne
	@JoinColumn(name="id_service_package")
	private ServicePackage servicePackage;

	//bi-directional many-to-one association to OrdertableOptional
	@OneToMany(mappedBy="ordertable")
	private List<OrdertableOptional> ordertableOptionals;

	public Ordertable() {
	}
	
	public Ordertable(ServicePackage servicePackage, Consumer consumer, Date dateOfCreation, Integer totalPrice, Date dateOfSubscription, int valid, int idValidityPeriod) {
	      this.servicePackage = servicePackage; 
	      this.consumer = consumer; 
	      this.dateOfCreation = dateOfCreation;
	      this.totalPrice = totalPrice; 
	      this.dateOfSubscription = dateOfSubscription; 
	      this.valid = valid; 
	      this.idValidityPeriod = idValidityPeriod;
	    }
	
	public Ordertable(ServicePackage servicePackage, Consumer consumer, Date dateOfCreation, Integer totalPrice, Date dateOfSubscription, int valid, int idValidityPeriod, List<Optional> optionals) {
        this.servicePackage = servicePackage; 
        this.consumer = consumer; 
        this.dateOfCreation = dateOfCreation;
        this.totalPrice = totalPrice; 
        this.dateOfSubscription = dateOfSubscription; 
        this.valid = valid; 
        this.idValidityPeriod = idValidityPeriod;
        this.optionals = optionals; 
      }

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDateOfCreation() {
		return this.dateOfCreation;
	}

	public void setDateOfCreation(Date dateOfCreation) {
		this.dateOfCreation = dateOfCreation;
	}

	public Date getDateOfSubscription() {
		return this.dateOfSubscription;
	}

	public void setDateOfSubscription(Date dateOfSubscription) {
		this.dateOfSubscription = dateOfSubscription;
	}

	public int getIdValidityPeriod() {
		return this.idValidityPeriod;
	}

	public void setIdValidityPeriod(int idValidityPeriod) {
		this.idValidityPeriod = idValidityPeriod;
	}

	public int getTotalPrice() {
		return this.totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getValid() {
		return this.valid;
	}

	public void setValid(int valid) {
		this.valid = valid;
	}

	public Consumer getConsumer() {
		return this.consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	public List<Optional> getOptionals() {
		return this.optionals;
	}

	public void setOptionals(List<Optional> optionals) {
		this.optionals = optionals;
	}

	public ServicePackage getServicePackage() {
		return this.servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

	public List<OrdertableOptional> getOrdertableOptionals() {
		return this.ordertableOptionals;
	}

	public void setOrdertableOptionals(List<OrdertableOptional> ordertableOptionals) {
		this.ordertableOptionals = ordertableOptionals;
	}

	public OrdertableOptional addOrdertableOptional(OrdertableOptional ordertableOptional) {
		getOrdertableOptionals().add(ordertableOptional);
		ordertableOptional.setOrdertable(this);

		return ordertableOptional;
	}

	public OrdertableOptional removeOrdertableOptional(OrdertableOptional ordertableOptional) {
		getOrdertableOptionals().remove(ordertableOptional);
		ordertableOptional.setOrdertable(null);

		return ordertableOptional;
	}

}