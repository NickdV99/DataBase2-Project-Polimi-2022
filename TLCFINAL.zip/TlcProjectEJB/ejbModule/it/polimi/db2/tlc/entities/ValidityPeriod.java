package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the validity_period database table.
 * 
 */
@Entity
@Table(name="validity_period")
@NamedQuery(name="ValidityPeriod.findAll", query="SELECT v FROM ValidityPeriod v")
@NamedQuery(name="ValidityPeriod.findByServicePackage", query="SELECT v FROM ValidityPeriod v WHERE v.servicePackage.id = :packageId")
public class ValidityPeriod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private int months;

	private int price;

	//bi-directional many-to-one association to ReportPurchasePackageValidityPeriod
	@OneToMany(mappedBy="validityPeriod")
	private List<ReportPurchasePackageValidityPeriod> reportPurchasePackageValidityPeriods;

	//bi-directional many-to-one association to ServicePackage
	@ManyToOne
	@JoinColumn(name="id_service_package")
	private ServicePackage servicePackage;

	public ValidityPeriod() {
	}
	
	public ValidityPeriod(int id, ServicePackage servicePackage, int months, int price) {
	    this.id = id;
	    this.servicePackage = servicePackage;
	    this.months = months; 
	    this.price = price;
	  }
	  
	  public ValidityPeriod(ServicePackage servicePackage, int months, int price) {
	    this.servicePackage = servicePackage;
	    this.months = months; 
	    this.price = price;
	  }

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMonths() {
		return this.months;
	}

	public void setMonths(int months) {
		this.months = months;
	}

	public int getPrice() {
		return this.price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public List<ReportPurchasePackageValidityPeriod> getReportPurchasePackageValidityPeriods() {
		return this.reportPurchasePackageValidityPeriods;
	}

	public void setReportPurchasePackageValidityPeriods(List<ReportPurchasePackageValidityPeriod> reportPurchasePackageValidityPeriods) {
		this.reportPurchasePackageValidityPeriods = reportPurchasePackageValidityPeriods;
	}

	public ReportPurchasePackageValidityPeriod addReportPurchasePackageValidityPeriod(ReportPurchasePackageValidityPeriod reportPurchasePackageValidityPeriod) {
		getReportPurchasePackageValidityPeriods().add(reportPurchasePackageValidityPeriod);
		reportPurchasePackageValidityPeriod.setValidityPeriod(this);

		return reportPurchasePackageValidityPeriod;
	}

	public ReportPurchasePackageValidityPeriod removeReportPurchasePackageValidityPeriod(ReportPurchasePackageValidityPeriod reportPurchasePackageValidityPeriod) {
		getReportPurchasePackageValidityPeriods().remove(reportPurchasePackageValidityPeriod);
		reportPurchasePackageValidityPeriod.setValidityPeriod(null);

		return reportPurchasePackageValidityPeriod;
	}

	public ServicePackage getServicePackage() {
		return this.servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

}