package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the alert database table.
 * 
 */
@Entity
@Table(name="alert")
@NamedQuery(name="Alert.findAll", query="SELECT a FROM Alert a")
public class Alert implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_consumer")
	private int idConsumer;

	private int amount;

	private String email;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="last_rejection")
	private Date lastRejection;

	private String username;

	//bi-directional one-to-one association to Consumer
	@OneToOne
	@PrimaryKeyJoinColumn(name="id_consumer")
	private Consumer consumer;

	public Alert() {
	}

	public int getIdConsumer() {
		return this.idConsumer;
	}

	public void setIdConsumer(int idConsumer) {
		this.idConsumer = idConsumer;
	}

	public int getAmount() {
		return this.amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getLastRejection() {
		return this.lastRejection;
	}

	public void setLastRejection(Date lastRejection) {
		this.lastRejection = lastRejection;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Consumer getConsumer() {
		return this.consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

}