package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the ordertable_optional database table.
 * 
 */
@Embeddable
public class OrdertableOptionalPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="id_ordertable", insertable=false, updatable=false)
	private int idOrdertable;

	@Column(name="id_optional", insertable=false, updatable=false)
	private int idOptional;

	public OrdertableOptionalPK() {
	}
	public int getIdOrdertable() {
		return this.idOrdertable;
	}
	public void setIdOrdertable(int idOrdertable) {
		this.idOrdertable = idOrdertable;
	}
	public int getIdOptional() {
		return this.idOptional;
	}
	public void setIdOptional(int idOptional) {
		this.idOptional = idOptional;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof OrdertableOptionalPK)) {
			return false;
		}
		OrdertableOptionalPK castOther = (OrdertableOptionalPK)other;
		return 
			(this.idOrdertable == castOther.idOrdertable)
			&& (this.idOptional == castOther.idOptional);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.idOrdertable;
		hash = hash * prime + this.idOptional;
		
		return hash;
	}
}