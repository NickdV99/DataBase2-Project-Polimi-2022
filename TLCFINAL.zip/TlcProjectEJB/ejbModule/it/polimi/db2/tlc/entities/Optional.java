package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the optional database table.
 * 
 */
@Entity
@Table(name="optional")
@NamedQuery(name="Optional.findAll", query="SELECT o FROM Optional o")
public class Optional implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private int fee;

	private String name;

	//bi-directional many-to-many association to Ordertable
	@ManyToMany(mappedBy="optionals")
	private List<Ordertable> ordertables;

	//bi-directional many-to-one association to OrdertableOptional
	@OneToMany(mappedBy="optional")
	private List<OrdertableOptional> ordertableOptionals;

	//bi-directional many-to-many association to ServicePackage
	@ManyToMany(mappedBy="optionals")
	private List<ServicePackage> servicePackages;

	public Optional() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFee() {
		return this.fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Ordertable> getOrdertables() {
		return this.ordertables;
	}

	public void setOrdertables(List<Ordertable> ordertables) {
		this.ordertables = ordertables;
	}

	public List<OrdertableOptional> getOrdertableOptionals() {
		return this.ordertableOptionals;
	}

	public void setOrdertableOptionals(List<OrdertableOptional> ordertableOptionals) {
		this.ordertableOptionals = ordertableOptionals;
	}

	public OrdertableOptional addOrdertableOptional(OrdertableOptional ordertableOptional) {
		getOrdertableOptionals().add(ordertableOptional);
		ordertableOptional.setOptional(this);

		return ordertableOptional;
	}

	public OrdertableOptional removeOrdertableOptional(OrdertableOptional ordertableOptional) {
		getOrdertableOptionals().remove(ordertableOptional);
		ordertableOptional.setOptional(null);

		return ordertableOptional;
	}

	public List<ServicePackage> getServicePackages() {
		return this.servicePackages;
	}

	public void setServicePackages(List<ServicePackage> servicePackages) {
		this.servicePackages = servicePackages;
	}

}