package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the report_purchases_package database table.
 * 
 */
@Entity
@Table(name="report_purchases_package")
@NamedQuery(name="ReportPurchasesPackage.findAll", query="SELECT r FROM ReportPurchasesPackage r")
public class ReportPurchasesPackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_service_package")
	private int idServicePackage;

	@Column(name="total_purchase")
	private int totalPurchase;

	//bi-directional one-to-one association to ServicePackage
	@OneToOne
	@PrimaryKeyJoinColumn(name="id_service_package")
	private ServicePackage servicePackage;

	public ReportPurchasesPackage() {
	}

	public int getIdServicePackage() {
		return this.idServicePackage;
	}

	public void setIdServicePackage(int idServicePackage) {
		this.idServicePackage = idServicePackage;
	}

	public int getTotalPurchase() {
		return this.totalPurchase;
	}

	public void setTotalPurchase(int totalPurchase) {
		this.totalPurchase = totalPurchase;
	}

	public ServicePackage getServicePackage() {
		return this.servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

}