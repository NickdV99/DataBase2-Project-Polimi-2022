package it.polimi.db2.tlc.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the report_purchase_package_validity_period database table.
 * 
 */
@Embeddable
public class ReportPurchasePackageValidityPeriodPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="id_package", insertable=false, updatable=false)
	private int idPackage;

	@Column(name="id_validity_period", insertable=false, updatable=false)
	private int idValidityPeriod;

	public ReportPurchasePackageValidityPeriodPK() {
	}
	public int getIdPackage() {
		return this.idPackage;
	}
	public void setIdPackage(int idPackage) {
		this.idPackage = idPackage;
	}
	public int getIdValidityPeriod() {
		return this.idValidityPeriod;
	}
	public void setIdValidityPeriod(int idValidityPeriod) {
		this.idValidityPeriod = idValidityPeriod;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ReportPurchasePackageValidityPeriodPK)) {
			return false;
		}
		ReportPurchasePackageValidityPeriodPK castOther = (ReportPurchasePackageValidityPeriodPK)other;
		return 
			(this.idPackage == castOther.idPackage)
			&& (this.idValidityPeriod == castOther.idValidityPeriod);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.idPackage;
		hash = hash * prime + this.idValidityPeriod;
		
		return hash;
	}
}