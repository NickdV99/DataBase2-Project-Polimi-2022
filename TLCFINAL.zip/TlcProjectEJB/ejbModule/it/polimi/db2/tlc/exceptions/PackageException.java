package it.polimi.db2.tlc.exceptions;

public class PackageException extends Exception {
	private static final long serialVersionUID = 1L;

	public PackageException(String message) {
		super(message);
	}
}
