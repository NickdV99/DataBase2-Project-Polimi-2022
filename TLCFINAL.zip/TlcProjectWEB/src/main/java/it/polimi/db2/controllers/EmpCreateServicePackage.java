package it.polimi.db2.controllers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.db2.tlc.services.*;
import it.polimi.db2.tlc.entities.*;

@WebServlet("/EmpCreateServicePackage")
public class EmpCreateServicePackage extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.tlc.services/PackageService")
	private PackageService pService;
	@EJB(name = "it.polimi.db2.tlc.services/ServiceService")
	private ServiceService sService;
	@EJB(name = "it.polimi.db2.tlc.services/ValidityPeriodService")
	private ValidityPeriodService vService;
	@EJB(name = "it.polimi.db2.tlc.services/OrderService")
	private OrderService oService;
	@EJB(name = "it.polimi.db2.tlc.services/OptionalService")
	private OptionalService optService;



	public EmpCreateServicePackage() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// If the user is not logged in (not present in session) redirect to the login
		String loginpath = getServletContext().getContextPath() + "/index.html";
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("employee") == null) {
			response.sendRedirect(loginpath);
			return;
		}

		// obtain and escape params

		List<Service>  services = null;
		List<ServicePackage> servicePackages = null; 
		
		
		//get all services		
		try {
			  services = sService.findAllServices();	
		} catch (Exception e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}
		
		//get all service Packages		
		try {
			  servicePackages = pService.findAllPackages();	
		} catch (Exception e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}
		
		
		// return the employee to the right view
		String path = "/WEB-INF/EmployeeHome.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("services", services);
		ctx.setVariable("servicePackages", servicePackages);
		templateEngine.process(path, ctx, response.getWriter());

	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//doGet(request,response);
		
		String servicePackageName = null; 
		List<Integer> serviceIds = new ArrayList<Integer>();
		List<Service> serviceObjects = new ArrayList<Service>();
		List<ValidityPeriod> validityPeriods = new ArrayList<ValidityPeriod>();
		ValidityPeriod validityPeriodObject = new ValidityPeriod(); 
		ServicePackage servicePackage = null; 
		Optional optional = new Optional(); 
		int months = 0; 
		int price = 0; 
		int id = 0; 
		int idValidityPeriod = 0; 
		
		
		if(StringEscapeUtils.escapeJava(request.getParameter("id")) != null) {
			
			if (request.getParameterMap().containsKey("id") && request.getParameter("id") != ""
					&& !request.getParameter("id").isEmpty()) {
			try {

					id = Integer.parseInt(request.getParameter("id"));
					System.out.println(id);
									
				}catch (Exception e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters for id");
					return;
				}
			
			}
			
			
			if (request.getParameterMap().containsKey("servicePackageName") && request.getParameter("servicePackageName") != ""
					&& !request.getParameter("servicePackageName").isEmpty()) {
			try {

					servicePackageName = StringEscapeUtils.escapeJava(request.getParameter("servicePackageName"));
					System.out.println(servicePackageName.toString());
					
				}catch (Exception e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters for packageName");
					return;
				}
			
			}
			
			if (request.getParameterMap().containsKey("serviceIds") && request.getParameter("serviceIds") != ""
					&& !request.getParameter("serviceIds").isEmpty()) {
				
				try {
				for (String str : request.getParameterValues("serviceIds")){
		            serviceIds.add(Integer.valueOf(str));
		        }
				System.out.println(serviceIds.toString());
				for(int i : serviceIds){
					Service service = sService.findServiceById(i); 
					serviceObjects.add(service);	
				}
				System.out.println(serviceObjects);
				}catch (Exception e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters for serviceIds");
					return;
				}
				
			}
			
			if (request.getParameterMap().containsKey("periodId") && request.getParameter("periodId") != ""
					&& !request.getParameter("periodId").isEmpty()) {
				
				try {
					months = Integer.parseInt(request.getParameter("periodId"));
					System.out.println(months);
				}catch (Exception e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters for periodId");
					return;
				}
				
			}
			
			if (request.getParameterMap().containsKey("priceId") && request.getParameter("priceId") != ""
					&& !request.getParameter("priceId").isEmpty()) {
				
				try {
					price = Integer.parseInt(request.getParameter("priceId"));
					System.out.println(price);
				}catch (Exception e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters for periodId");
					return;
				}
				
			}
			
			if (request.getParameterMap().containsKey("id") && request.getParameter("id") != ""
					&& !request.getParameter("id").isEmpty()) {
			
				try {
					pService.createServicePackageId(id);
				} catch (Exception e) {
					response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to create ServicePacakge");
					
				}
			}
		

			if (request.getParameterMap().containsKey("id") && request.getParameter("id") != ""
					&& !request.getParameter("id").isEmpty()) {
			try {
			System.out.println("Id del servicePackage sopra " + id);
			servicePackage = pService.findServicePackageById(id);
			System.out.println("Id del service Package sotto" + servicePackage.getId());
			validityPeriodObject = vService.createValidityPeriod(servicePackage, months, price);
			validityPeriods.add(validityPeriodObject);
			}catch (Exception e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Not possible to add validity period object to list");
				return;
			}
			}
			
				// Create service Package in DB
			
			if (request.getParameterMap().containsKey("servicePackageName") && request.getParameter("servicePackageName") != ""
					&& !request.getParameter("servicePackageName").isEmpty()) {
			
				try {
					pService.createServicePackage(id,servicePackageName, serviceObjects, validityPeriods);
				} catch (Exception e) {
					response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to create ServicePacakge");
					
				}
			}
			
			}
			
			if(StringEscapeUtils.escapeJava(request.getParameter("optionalId")) != null) {
				
				optional.setName(StringEscapeUtils.escapeJava(request.getParameter("optionalId")));
				optional.setFee(Integer.parseInt(request.getParameter("optionalFeeId")));
				
				try {
					optService.createOptional(optional);
					}catch(Exception e) {
						response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error in the creation of package");
						return;
					}
			}
			
			
			doGet(request,response);
		
	}

	public void destroy() {

	}

}
