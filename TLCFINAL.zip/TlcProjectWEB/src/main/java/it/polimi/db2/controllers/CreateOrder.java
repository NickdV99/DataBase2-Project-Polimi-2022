package it.polimi.db2.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
//import java.util.List;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.db2.tlc.services.*;
import it.polimi.db2.tlc.entities.*;

@WebServlet("/CreateOrder")
public class CreateOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.mission.services/OrderService")
	private OrderService ordService;


	
	public CreateOrder() {
		super();
	}
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// If the user is not logged in (not present in session) redirect to the login
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("consumer") == null) {
			String loginpath = getServletContext().getContextPath() + "/index.html";
			response.sendRedirect(loginpath);
			return;
		}

		
		// Create Order in DB
		
		//boolean isBadRequest = false;
		Consumer consumer = (Consumer) session.getAttribute("consumer");
		ServicePackage chosenServicePackage = (ServicePackage) session.getAttribute("chosenServicePackage");
		ValidityPeriod chosenPeriodObject = (ValidityPeriod) session.getAttribute("chosenPeriodObject");
		List<Optional> chosenOptionalObjects = (List<Optional>) session.getAttribute("chosenOptionalObjects");
		//List<OrdertableOptional> chosenOrdetableOptionalObjects = new ArrayList<OrdertableOptional>();
		Date dateOfSubscription = (Date) session.getAttribute("dateOfSubscription");
		Integer totalPrice = (Integer) session.getAttribute("totalPrice");
		Date dateOfCreation =  new Date(System.currentTimeMillis());
		Ordertable chosenOrdertable = null;
		Ordertable rejectedOrderObject = (Ordertable) session.getAttribute("rejectedOrderObject");
		int valid = 0;
		int idValidityPeriod = 0;

		

		
		
		if(rejectedOrderObject == null) {
		try {
			idValidityPeriod = chosenPeriodObject.getId();
			System.out.println("Id del periodo di validità: " + idValidityPeriod);
			for(Optional o : chosenOptionalObjects) {
				System.out.println("Id degli Opzionali scelti: " + o.getId());
			}
			int idOrdertable = (int) (Math.random() * 1000000);
			chosenOrdertable = ordService.createOrdertableWOptional(idOrdertable, chosenServicePackage,consumer,dateOfCreation,totalPrice,dateOfSubscription,valid,idValidityPeriod,chosenOptionalObjects);			
			System.out.println("Ordine completo creato con bit settato a " + chosenOrdertable.getValid());
		} catch (Exception e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to create order");
			return;
		}
		}else {
			System.out.println("Rejected order object is not null");
			rejectedOrderObject = ordService.updateOrdertable(rejectedOrderObject, consumer.getId());
			System.out.println("Ordine rigettato aggiornato con bit settato a " + rejectedOrderObject.getValid());
		}
		
		// return the user to the right view
		String path = "/WEB-INF/StatusPage.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		request.getSession().setAttribute("chosenOrdertable", chosenOrdertable);
		templateEngine.process(path, ctx, response.getWriter());
	}

	public void destroy() {
	}

}
