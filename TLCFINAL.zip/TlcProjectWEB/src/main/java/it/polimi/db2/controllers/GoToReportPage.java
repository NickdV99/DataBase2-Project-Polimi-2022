package it.polimi.db2.controllers;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.db2.tlc.services.*;
import it.polimi.db2.tlc.entities.*;

@WebServlet("/GoToReportPage")
public class GoToReportPage extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.tlc.services/ReportService")
	private ReportService rService;

	public GoToReportPage() {
		super();
	}
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// If the consumer is not logged in (not present in session) redirect to the login
		String loginpath = getServletContext().getContextPath() + "/index.html";
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("employee") == null) {
			response.sendRedirect(loginpath);
			return;
		}

		Employee employee = (Employee) session.getAttribute("employee");
		List<ReportPurchasesPackage> purchasedPackages = null;
		List<ReportPurchasePackageValidityPeriod> purchasedPackagesVP = null;
		List<ReportAvegareOptionalPackage> averageOptional = null;
		List<ReportTotalSalesPackage> totalSales = null;
		List<ReportBestSellerOptional> bestSellerOptional = null;
		List<ReportInsolventUser> insolventUsers = null;
		List<ReportSuspendedOrder> suspendedOrders = null;
		List<Alert> alerts = null;
		
		try {
			purchasedPackages = rService.findAllReportPurchasesPackage();
		}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
				return;
		}
		try {
			purchasedPackagesVP = rService.findAllReportPurchasePackageValidityPeriod();
		}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
				return;
		}
		try {
			averageOptional = rService.findAllReportAvegareOptionalPackage();
		}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
				return;
		}
		try {
			totalSales = rService.findAllReportTotalSalesPackage();
		}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
				return;
		}
		try {
			bestSellerOptional = rService.findAllReportBestSellerOptional();
		}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
				return;
		}
		try {
			insolventUsers = rService.findAllReportInsolventUsers();
		}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
				return;
		}
		try {
			suspendedOrders = rService.findAllReportSuspendedOrders();
		}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
				return;
		}
		try {
			alerts = rService.findAllAlerts();
		}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
				return;
		}

		// Pass all the parameters to the Home.html
		String path = "/WEB-INF/ReportPage.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("purchasedPackages", purchasedPackages);
		ctx.setVariable("purchasedPackagesVP", purchasedPackagesVP);
		ctx.setVariable("averageOptional", averageOptional);
		ctx.setVariable("totalSales", totalSales);
		ctx.setVariable("bestSellerOptional", bestSellerOptional);
		ctx.setVariable("insolventUsers", insolventUsers);
		ctx.setVariable("suspendedOrders", suspendedOrders);
		ctx.setVariable("alerts", alerts);

		templateEngine.process(path, ctx, response.getWriter());
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void destroy() {
	}
	
}
