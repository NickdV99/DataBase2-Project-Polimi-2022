package it.polimi.db2.controllers;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.polimi.db2.tlc.services.*;
import it.polimi.db2.tlc.entities.*;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@WebServlet("/GoToOrderPage")
public class GoToOrderPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.tlc.services/PackageService")
	private PackageService pService;
	@EJB(name = "it.polimi.db2.tlc.services/ValidityPeriodService")
	private ValidityPeriodService vService;
	@EJB(name = "it.polimi.db2.tlc.services/OptionalService")
	private OptionalService oService; 

	public GoToOrderPage() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// If the user is not logged in (not present in session) redirect to the login
		String loginpath = getServletContext().getContextPath() + "/index.html";
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("consumer") == null) {
			response.sendRedirect(loginpath);
			return;
		}
		
		//Declarations
		List<ServicePackage>  servicePackages = null;
		ServicePackage chosenServicePackage = null;
		List<ValidityPeriod> validityPeriods = null; 
		List<Optional> optionals = null; 

		
		//get all service_packages		
		try {
			  servicePackages = pService.findAllPackages();	
		} catch (Exception e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}
		
		//choose the service_package
		Integer chosen = null;
		if (request.getParameterMap().containsKey("packageId") && request.getParameter("packageId") != ""
				&& !request.getParameter("packageId").isEmpty()) {
			try {
				chosen = Integer.parseInt(request.getParameter("packageId"));
			} catch (Exception e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters");
				return;
			}
		}
		
		if (chosen != null) {
			try {
			chosenServicePackage = pService.findServicePackageById(chosen);
			}catch(Exception e) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find package");
				return;
			}
		}else if(chosen == null | chosenServicePackage == null) {
			chosenServicePackage = pService.findDefault();
		}
	
		
		//choose the validity period associated to the package(different service packages with the same validity period have different price)
		try {
		validityPeriods = vService.findByServicePackage(chosenServicePackage.getId());
		}catch(Exception e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find validity period");
			return;
		}
		
		
		try {
		optionals = oService.findAllOptionals();
		}catch(Exception e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to find optionals");
			return;
		}
		
		
		// Pass all the parameters to Order.html
		String path = "/WEB-INF/Order.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("servicePackages", servicePackages);
		request.getSession().setAttribute("chosenServicePackage", chosenServicePackage);
		ctx.setVariable("validityPeriods", validityPeriods);
		ctx.setVariable("optionals", optionals);		
		templateEngine.process(path, ctx, response.getWriter());
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void destroy() {
	}

}
