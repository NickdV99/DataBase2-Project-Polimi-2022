package it.polimi.db2.controllers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.polimi.db2.tlc.services.*;
import it.polimi.db2.tlc.entities.*;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@WebServlet("/GoToConfirmation")
public class GoToConfirmation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.tlc.services/PackageService")
	private PackageService pService;
	@EJB(name = "it.polimi.db2.tlc.services/ValidityPeriodService")
	private ValidityPeriodService vService;
	@EJB(name = "it.polimi.db2.tlc.services/OptionalService")
	private OptionalService oService; 
	@EJB(name = "it.polimi.db2.tlc.services/OrderService")
	private OrderService ordService; 

	public GoToConfirmation() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// If the user is not logged in (not present in session) redirect to the login
		String loginpath = getServletContext().getContextPath() + "/index.html";
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("consumer") == null) {
			response.sendRedirect(loginpath);
			return;
		}
		
		// obtain and escape params
			
		
		Integer chosenPeriod = null; 
		List<Integer> chosenOptionals = new ArrayList<Integer>();
		Date dateOfSubscription = null; 
		ValidityPeriod chosenPeriodObject = null; 
		List<Optional> chosenOptionalObjects = new ArrayList<Optional>();
		int rejectedOrderId = 0; 
		Integer totalPrice = null; 
		Ordertable rejectedOrderObject = null; 
		
		if(request.getParameterMap().containsKey("rejectedOrderId") && request.getParameter("rejectedOrderId") != ""
				&& !request.getParameter("rejectedOrderId").isEmpty()) {
			try {
				
				rejectedOrderId = Integer.parseInt(request.getParameter("rejectedOrderId"));
				System.out.println("Rejected Order ID: "+ rejectedOrderId);		
				rejectedOrderObject = ordService.findOrdertableById(rejectedOrderId);
				
				// Go to the Confirmation page and bring parameters
				String path = "/WEB-INF/Confirmation.html";
				ServletContext servletContext = getServletContext();
				final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
				request.getSession().setAttribute("rejectedOrderId", rejectedOrderId);
				request.getSession().setAttribute("rejectedOrderObject", rejectedOrderObject);
				
				templateEngine.process(path, ctx, response.getWriter());
				
			}catch (Exception e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters for rejectedOrderId");
				return;
			}			
			
		}else {
			System.out.println("NO REJECTED ORDER, PROCED NORMALLY");
		}
			
		
		if (request.getParameterMap().containsKey("optionalIds") && request.getParameter("optionalIds") != ""
				&& !request.getParameter("optionalIds").isEmpty()) {
			try {
				
				for (String str : request.getParameterValues("optionalIds")) {
		            chosenOptionals.add(Integer.valueOf(str));
		        }
				System.out.println(chosenOptionals.toString());
				
				for(int i : chosenOptionals){
					Optional optional = oService.findOptionaleById(i); 
					chosenOptionalObjects.add(optional);	
				}
				System.out.println(chosenOptionalObjects);
				
				
			} catch (Exception e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters");
				return;
			}
		}
		
		
		if (request.getParameterMap().containsKey("periodId") && request.getParameter("periodId") != ""
				&& !request.getParameter("periodId").isEmpty()) {
			try {
				chosenPeriod = Integer.parseInt(request.getParameter("periodId"));
				chosenPeriodObject = vService.findValidityPeriodById(chosenPeriod);
				
				int totalOptionalFee = 0; 
				
				for (Optional opt : chosenOptionalObjects) {
					totalOptionalFee = opt.getFee() + totalOptionalFee;
				}
				
				System.out.println(totalOptionalFee);
				
				totalPrice = chosenPeriodObject.getPrice() * chosenPeriodObject.getMonths() + totalOptionalFee * chosenPeriodObject.getMonths();
				
				System.out.println(totalPrice);
								
			} catch (Exception e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters");
				return;
			}
		}
		
		                      
		if (request.getParameterMap().containsKey("dateOfSubscription") && request.getParameter("dateOfSubscription") != ""
				&& !request.getParameter("dateOfSubscription").isEmpty()) {
			try {
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				dateOfSubscription = (Date) sdf.parse(request.getParameter("dateOfSubscription"));
				System.out.println(dateOfSubscription.toString());
				
			} catch (Exception e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters");
				return;
			}
		}else { response.sendError(HttpServletResponse.SC_BAD_REQUEST, " date is null");
				return;		
				}
		
		
		
		// Go to the Confirmation page and bring parameters parameters
		String path = "/WEB-INF/Confirmation.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		request.getSession().setAttribute("chosenPeriodObject", chosenPeriodObject);
		request.getSession().setAttribute("chosenOptionalObjects", chosenOptionalObjects);
		request.getSession().setAttribute("dateOfSubscription", dateOfSubscription);
		request.getSession().setAttribute("totalPrice", totalPrice);
		request.getSession().setAttribute("rejectedOrderId", rejectedOrderId);
		templateEngine.process(path, ctx, response.getWriter());
		
		//path = getServletContext().getContextPath() + "/GoToConfirmation";  DIFFERENCES WITH ABOVE
		//response.sendRedirect(path);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	public void destroy() {
	}

}

