-- MySQL dump 10.13  Distrib 8.0.27, for Linux (x86_64)
--
-- Host: localhost    Database: db_tlc_project
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.21.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alert`
--

DROP TABLE IF EXISTS `alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert` (
  `id_consumer` int NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `amount` int NOT NULL DEFAULT '0',
  `last_rejection` datetime DEFAULT NULL,
  PRIMARY KEY (`id_consumer`),
  KEY `fk_alert_usertable_idx` (`id_consumer`),
  CONSTRAINT `fk_alert_usertable` FOREIGN KEY (`id_consumer`) REFERENCES `consumer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert`
--

LOCK TABLES `alert` WRITE;
/*!40000 ALTER TABLE `alert` DISABLE KEYS */;
/*!40000 ALTER TABLE `alert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumer`
--

DROP TABLE IF EXISTS `consumer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `insolvent` tinyint NOT NULL,
  `counter` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumer`
--

LOCK TABLES `consumer` WRITE;
/*!40000 ALTER TABLE `consumer` DISABLE KEYS */;
INSERT INTO `consumer` VALUES (1,'nico','passnico','nico@mail.it',0,0),(18,'angi','passangi','angi@mail.it',0,0),(21,'carlo','passcarlo','carlo@mail.it',0,0);
/*!40000 ALTER TABLE `consumer` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `consumer_insolvent_counter_BEFORE_INSERT` BEFORE INSERT ON `consumer` FOR EACH ROW BEGIN
	IF (NEW.counter > 1) THEN
		SET NEW.insolvent = 1;
	ELSE SET NEW.insolvent = 0;
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `consumer_AFTER_INSERT` AFTER INSERT ON `consumer` FOR EACH ROW BEGIN
	IF (NEW.counter = 3) THEN
			INSERT INTO `alert`(id_consumer,username,email) VALUES (NEW.id,NEW.username,NEW.email);
            UPDATE `alert` SET amount = (SELECT total_price FROM `ordertable` WHERE id_consumer = NEW.id AND valid = 0 ORDER BY date_of_subscription DESC LIMIT 1),
								last_rejection = (SELECT date_of_creation FROM `ordertable` WHERE id_consumer = NEW.id AND valid = 0 ORDER BY date_of_subscription DESC LIMIT 1);
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `consumer_insolvent_counter_BEFORE_UPDATE` BEFORE UPDATE ON `consumer` FOR EACH ROW BEGIN
	IF (NEW.counter > 1) THEN
		SET NEW.insolvent = 1;
	ELSE SET NEW.insolvent = 0;
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `consumer_AFTER_UPDATE` AFTER UPDATE ON `consumer` FOR EACH ROW BEGIN

	 IF (NEW.counter = 3 AND NOT EXISTS (SELECT id_consumer FROM `alert` WHERE id_consumer = NEW.id)) THEN
			INSERT INTO `alert`(id_consumer,username,email) VALUES (NEW.id,NEW.username,NEW.email);
             UPDATE `alert` SET amount = (SELECT total_price FROM `ordertable` WHERE id_consumer = NEW.id AND valid = 0 ORDER BY date_of_subscription DESC LIMIT 1),
								last_rejection = (SELECT date_of_creation FROM `ordertable` WHERE id_consumer = NEW.id AND valid = 0 ORDER BY date_of_subscription DESC LIMIT 1);
             
	ELSE IF(OLD.counter = 3 AND EXISTS (SELECT id_consumer FROM `alert` WHERE id_consumer = OLD.id) AND
			NOT EXISTS (SELECT id FROM `consumer` 
            WHERE id = (SELECT id_consumer FROM `alert` WHERE id_consumer = NEW.id) AND counter = 3))THEN
			DELETE FROM `alert` WHERE id_consumer = NEW.id;
		END IF;
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `consumer_AFTER_DELETE` AFTER DELETE ON `consumer` FOR EACH ROW BEGIN
	IF(OLD.counter = 3 AND EXISTS (SELECT id_consumer FROM `alert` WHERE id_consumer = OLD.id) AND
			NOT EXISTS (SELECT id FROM `consumer` 
            WHERE id = (SELECT id_consumer FROM `alert` WHERE id_consumer = OLD.id) AND counter = 3))THEN
			DELETE FROM `alert` WHERE id_consumer = OLD.id;
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'emp1','emp1pass','emp1@gmail.it');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `optional`
--

DROP TABLE IF EXISTS `optional`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `optional` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `fee` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `optional`
--

LOCK TABLES `optional` WRITE;
/*!40000 ALTER TABLE `optional` DISABLE KEYS */;
INSERT INTO `optional` VALUES (1,'spotify',10),(2,'netflix',7),(3,'disney+',15),(4,'tim_vision',4),(5,'amazon_prime',17);
/*!40000 ALTER TABLE `optional` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordertable`
--

DROP TABLE IF EXISTS `ordertable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordertable` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_of_creation` datetime NOT NULL,
  `total_price` int NOT NULL,
  `date_of_subscription` datetime NOT NULL,
  `id_service_package` int NOT NULL,
  `id_consumer` int NOT NULL,
  `valid` int NOT NULL,
  `id_validity_period` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ordertable_usertable_idx` (`id_consumer`),
  KEY `fk_ordertable_validity_period_idx` (`id_validity_period`),
  KEY `fk_ordertable_service_package_idx` (`id_service_package`),
  CONSTRAINT `fk_ordertable_service_package` FOREIGN KEY (`id_service_package`) REFERENCES `service_package` (`id`),
  CONSTRAINT `fk_ordertable_usertable` FOREIGN KEY (`id_consumer`) REFERENCES `consumer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=484 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordertable`
--

LOCK TABLES `ordertable` WRITE;
/*!40000 ALTER TABLE `ordertable` DISABLE KEYS */;
INSERT INTO `ordertable` VALUES (43,'2022-02-23 22:37:50',672,'2022-02-23 23:00:00',1,1,1,2),(46,'2022-02-23 22:37:50',672,'2022-02-23 23:00:00',1,1,1,2);
/*!40000 ALTER TABLE `ordertable` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ordertable_BEFORE_INSERT` BEFORE INSERT ON `ordertable` FOR EACH ROW BEGIN

  IF (NOT EXISTS (SELECT id_service_package FROM report_purchases_package WHERE id_service_package = NEW.id_service_package)) THEN
    INSERT INTO report_purchases_package(id_service_package,total_purchase) VALUES (NEW.id_service_package,0);
    END IF;
    
    IF (NOT EXISTS (SELECT id_package FROM report_purchase_package_validity_period WHERE id_package = NEW.id_service_package)) THEN
    INSERT INTO report_purchase_package_validity_period(id_package,id_validity_period,total_purchase) VALUES (NEW.id_service_package,NEW.id_validity_period,0);
    END IF;
    
    IF (NOT EXISTS (SELECT id_package FROM report_total_sales_package WHERE id_package = NEW.id_service_package)) THEN
    INSERT INTO report_total_sales_package(id_package,value_package) VALUES (NEW.id_service_package,0);
    END IF;


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ordertable_AFTER_INSERT` AFTER INSERT ON `ordertable` FOR EACH ROW BEGIN

declare name_servicePackage varchar(45);
declare avg_optional float;

set name_servicePackage = (select service_package.name from service_package where service_package.id = NEW.id_service_package);
set avg_optional = (select avg(t1.count) from (select ordertable_optional.id_ordertable, count(ordertable_optional.id_optional) as count,
`ordertable`.id_service_package from ordertable_optional join `ordertable` on ordertable_optional.id_ordertable = `ordertable`.id group by (ordertable_optional.id_ordertable)) as t1 
where t1.id_service_package = new.id_service_package group by t1.id_service_package);
if(new.valid = 1 and avg_optional is not null) then 
	if(not exists (select report_avegare_optional_package.id_package from report_avegare_optional_package where report_avegare_optional_package.id_package = new.id_service_package)) 
    then insert into report_avegare_optional_package values (new.id_service_package, avg_optional, name_servicePackage);
    else update report_avegare_optional_package set report_avegare_optional_package.`average_optional` = avg_optional where report_avegare_optional_package.id_package = new.id_service_package;
    end if;
end if;

  IF(NEW.valid = 1)THEN
    
    UPDATE`report_purchases_package` SET total_purchase = total_purchase+1 
      WHERE id_service_package = NEW.id_service_package;
    
    UPDATE`report_purchase_package_validity_period` SET total_purchase = total_purchase+1 
      WHERE (id_package = NEW.id_service_package AND id_validity_period = NEW.id_validity_period);
      
    UPDATE`report_total_sales_package` SET  value_package = value_package + NEW.total_price
      WHERE id_package = NEW.id_service_package;
      
            
  END IF;
    
  IF(NEW.valid = 0) THEN
    IF (NOT EXISTS (SELECT consumer_id FROM report_insolvent_user WHERE consumer_id = NEW.id_consumer)) THEN
      INSERT INTO report_insolvent_user(consumer_id) VALUES (NEW.id_consumer);
    END IF;
        IF (NOT EXISTS (SELECT id_order FROM report_suspended_order WHERE id_order = NEW.id)) THEN
      INSERT INTO report_suspended_order(id_order) VALUES (NEW.id);
    END IF;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ordertable_BEFORE_UPDATE` BEFORE UPDATE ON `ordertable` FOR EACH ROW BEGIN

  IF (NOT EXISTS (SELECT id_service_package FROM report_purchases_package WHERE id_service_package = NEW.id_service_package)) THEN
    INSERT INTO report_purchases_package(id_service_package,total_purchase) VALUES (NEW.id_service_package,0);
    END IF;
    
    IF (NOT EXISTS (SELECT id_package FROM report_purchase_package_validity_period WHERE id_package = NEW.id_service_package)) THEN
    INSERT INTO report_purchase_package_validity_period(id_package,id_validity_period,total_purchase) VALUES (NEW.id_service_package,NEW.id_validity_period,0);
    END IF;
    
    IF (NOT EXISTS (SELECT id_package FROM report_total_sales_package WHERE id_package = NEW.id_service_package)) THEN
    INSERT INTO report_total_sales_package(id_package,value_package) VALUES (NEW.id_service_package,0);
    END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ordertable_AFTER_UPDATE` AFTER UPDATE ON `ordertable` FOR EACH ROW BEGIN

declare name_servicePackage varchar(45);
declare avg_optional float;

set name_servicePackage = (select service_package.name from service_package where service_package.id = NEW.id_service_package);
set avg_optional = (select avg(t1.count) from (select ordertable_optional.id_ordertable, count(ordertable_optional.id_optional) as count,
`ordertable`.id_service_package from ordertable_optional join `ordertable` on ordertable_optional.id_ordertable = `ordertable`.id group by (ordertable_optional.id_ordertable)) as t1
where t1.id_service_package = new.id_service_package group by t1.id_service_package);
if(new.valid = 1 and avg_optional is not null) then 
	if(not exists (select report_avegare_optional_package.id_package from report_avegare_optional_package where report_avegare_optional_package.id_package = new.id_service_package)) 
    then insert into report_avegare_optional_package values (new.id_service_package, avg_optional, name_servicePackage);
    else update report_avegare_optional_package set report_avegare_optional_package.`average_optional` = avg_optional where report_avegare_optional_package.id_package = new.id_service_package;
    end if;
end if;


 IF(NEW.valid = 1)THEN
    
    UPDATE`report_purchases_package` SET total_purchase = total_purchase+1 
      WHERE id_service_package = NEW.id_service_package;
       
    UPDATE`report_purchase_package_validity_period` SET total_purchase = total_purchase+1 
      WHERE (id_package = NEW.id_service_package AND id_validity_period = NEW.id_validity_period);
      
    UPDATE`report_total_sales_package` SET  value_package = value_package + NEW.total_price
      WHERE id_package = NEW.id_service_package;
        
        IF (EXISTS (SELECT id_order FROM report_suspended_order WHERE id_order = NEW.id)) THEN
      DELETE FROM report_suspended_order WHERE id_order = NEW.id;
    END IF;
    IF (EXISTS (SELECT consumer_id FROM report_insolvent_user WHERE consumer_id = NEW.id_consumer) AND
      NOT EXISTS (SELECT id_consumer FROM ordertable 
            WHERE id_consumer = (SELECT consumer_id FROM report_insolvent_user WHERE consumer_id = NEW.id_consumer) AND valid = 0)) THEN
      DELETE FROM report_insolvent_user WHERE consumer_id = NEW.id_consumer;
    END IF;
        
            
  END IF;
    
    IF(NEW.valid = 0) THEN
    IF (NOT EXISTS (SELECT consumer_id FROM report_insolvent_user WHERE consumer_id = NEW.id_consumer)) THEN
      INSERT INTO report_insolvent_user(consumer_id) VALUES (NEW.id_consumer);
    END IF;
        IF (NOT EXISTS (SELECT id_order FROM report_suspended_order WHERE id_order = NEW.id)) THEN
      INSERT INTO report_suspended_order(id_order) VALUES (NEW.id);
    END IF;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ordertable_AFTER_DELETE` AFTER DELETE ON `ordertable` FOR EACH ROW BEGIN

  IF(OLD.valid = 1)THEN
    
    IF((SELECT total_purchase FROM report_purchases_package WHERE id_service_package = OLD.id_service_package) > 0) THEN
    UPDATE`report_purchases_package` SET total_purchase = total_purchase-1 
      WHERE id_service_package = OLD.id_service_package;
    END IF;
        
        IF((SELECT total_purchase FROM report_purchase_package_validity_period WHERE id_package = OLD.id_service_package) > 0) THEN
        UPDATE`report_purchase_package_validity_period` SET total_purchase = total_purchase-1 
      WHERE (id_package = OLD.id_service_package AND id_validity_period = OLD.id_validity_period);
    END IF;
        
        UPDATE`report_total_sales_package` SET  value_package = value_package - OLD.total_price
      WHERE id_package = OLD.id_service_package;    
      
         
  END IF;
    
    IF(OLD.valid = 0) THEN
    IF(EXISTS (SELECT id_order FROM report_suspended_order WHERE id_order = OLD.id))THEN
      DELETE FROM report_suspended_order WHERE id_order = OLD.id;
    END IF;
    IF (EXISTS (SELECT consumer_id FROM report_insolvent_user WHERE consumer_id = OLD.id_consumer) AND
      NOT EXISTS (SELECT id_consumer FROM ordertable 
            WHERE id_consumer = (SELECT consumer_id FROM report_insolvent_user WHERE consumer_id = OLD.id_consumer) AND valid = 0)) THEN
      DELETE FROM report_insolvent_user WHERE consumer_id = OLD.id_consumer;
    END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ordertable_optional`
--

DROP TABLE IF EXISTS `ordertable_optional`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordertable_optional` (
  `id_ordertable` int NOT NULL,
  `id_optional` int NOT NULL,
  PRIMARY KEY (`id_ordertable`,`id_optional`),
  KEY `fk_ordertable_optional_1_idx` (`id_optional`),
  KEY `fk_optional_ordertable_idx` (`id_ordertable`),
  CONSTRAINT `fk_optional_ordertable2` FOREIGN KEY (`id_ordertable`) REFERENCES `ordertable` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ordertable_optional_1` FOREIGN KEY (`id_optional`) REFERENCES `optional` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordertable_optional`
--

LOCK TABLES `ordertable_optional` WRITE;
/*!40000 ALTER TABLE `ordertable_optional` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordertable_optional` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ordertable_optional_AFTER_INSERT` AFTER INSERT ON `ordertable_optional` FOR EACH ROW BEGIN

IF( EXISTS (SELECT 1 FROM ordertable_optional)) THEN
    UPDATE report_best_seller_optional SET 
    id_optional = (SELECT id_optional FROM ordertable_optional GROUP BY id_optional ORDER BY count(*) DESC LIMIT 1),
    total_sales_optional = (SELECT count(*) FROM ordertable_optional GROUP BY id_optional ORDER BY count(*) DESC LIMIT 1);
  ELSE UPDATE `report_best_seller_optional`SET id_optional = 0, total_sales_optional = 0;
  END IF;


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ordertable_optional_AFTER_UPDATE` AFTER UPDATE ON `ordertable_optional` FOR EACH ROW BEGIN

IF( EXISTS (SELECT 1 FROM ordertable_optional)) THEN
    UPDATE report_best_seller_optional 
    SET id_optional = (SELECT id_optional FROM ordertable_optional GROUP BY id_optional ORDER BY count(*) DESC LIMIT 1),
      total_sales_optional = (SELECT count(*) FROM ordertable_optional GROUP BY id_optional ORDER BY count(*) DESC LIMIT 1);
  ELSE UPDATE `report_best_seller_optional`SET id_optional = 0, total_sales_optional = 0;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ordertable_optional_AFTER_DELETE` AFTER DELETE ON `ordertable_optional` FOR EACH ROW BEGIN

IF( EXISTS (SELECT 1 FROM ordertable_optional)) THEN
    UPDATE report_best_seller_optional 
    SET id_optional = (SELECT id_optional FROM ordertable_optional GROUP BY id_optional ORDER BY count(*) DESC LIMIT 1),
      total_sales_optional = (SELECT count(*) FROM ordertable_optional GROUP BY id_optional ORDER BY count(*) DESC LIMIT 1);
  ELSE UPDATE `report_best_seller_optional`SET id_optional = 0, total_sales_optional = 0;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `report_avegare_optional_package`
--

DROP TABLE IF EXISTS `report_avegare_optional_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_avegare_optional_package` (
  `id_package` int NOT NULL,
  `average_optional` float NOT NULL,
  `name_service_package` varchar(45) NOT NULL,
  PRIMARY KEY (`id_package`),
  CONSTRAINT `fk_report_avegare_optional_package_1` FOREIGN KEY (`id_package`) REFERENCES `service_package` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_avegare_optional_package`
--

LOCK TABLES `report_avegare_optional_package` WRITE;
/*!40000 ALTER TABLE `report_avegare_optional_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_avegare_optional_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_best_seller_optional`
--

DROP TABLE IF EXISTS `report_best_seller_optional`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_best_seller_optional` (
  `id_optional` int NOT NULL,
  `total_sales_optional` int NOT NULL,
  PRIMARY KEY (`id_optional`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_best_seller_optional`
--

LOCK TABLES `report_best_seller_optional` WRITE;
/*!40000 ALTER TABLE `report_best_seller_optional` DISABLE KEYS */;
INSERT INTO `report_best_seller_optional` VALUES (1,3);
/*!40000 ALTER TABLE `report_best_seller_optional` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_insolvent_user`
--

DROP TABLE IF EXISTS `report_insolvent_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_insolvent_user` (
  `consumer_id` int NOT NULL,
  PRIMARY KEY (`consumer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_insolvent_user`
--

LOCK TABLES `report_insolvent_user` WRITE;
/*!40000 ALTER TABLE `report_insolvent_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_insolvent_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_purchase_package_validity_period`
--

DROP TABLE IF EXISTS `report_purchase_package_validity_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_purchase_package_validity_period` (
  `id_package` int NOT NULL,
  `id_validity_period` int NOT NULL,
  `total_purchase` int DEFAULT NULL,
  PRIMARY KEY (`id_package`,`id_validity_period`),
  KEY `fk_report_purchase_package_validity_period_validity_period_idx` (`id_validity_period`),
  CONSTRAINT `fk_report_purchase_package_validity_period_service_package` FOREIGN KEY (`id_package`) REFERENCES `service_package` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_report_purchase_package_validity_period_validity_period` FOREIGN KEY (`id_validity_period`) REFERENCES `validity_period` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_purchase_package_validity_period`
--

LOCK TABLES `report_purchase_package_validity_period` WRITE;
/*!40000 ALTER TABLE `report_purchase_package_validity_period` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_purchase_package_validity_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_purchases_package`
--

DROP TABLE IF EXISTS `report_purchases_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_purchases_package` (
  `id_service_package` int NOT NULL,
  `total_purchase` int DEFAULT NULL,
  PRIMARY KEY (`id_service_package`),
  CONSTRAINT `fk_report_purchases_package_service_package` FOREIGN KEY (`id_service_package`) REFERENCES `service_package` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_purchases_package`
--

LOCK TABLES `report_purchases_package` WRITE;
/*!40000 ALTER TABLE `report_purchases_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_purchases_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_suspended_order`
--

DROP TABLE IF EXISTS `report_suspended_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_suspended_order` (
  `id_order` int NOT NULL,
  PRIMARY KEY (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_suspended_order`
--

LOCK TABLES `report_suspended_order` WRITE;
/*!40000 ALTER TABLE `report_suspended_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_suspended_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_total_sales_package`
--

DROP TABLE IF EXISTS `report_total_sales_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_total_sales_package` (
  `id_package` int NOT NULL,
  `value_package` int DEFAULT NULL,
  PRIMARY KEY (`id_package`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_total_sales_package`
--

LOCK TABLES `report_total_sales_package` WRITE;
/*!40000 ALTER TABLE `report_total_sales_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_total_sales_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `minute` varchar(45) DEFAULT NULL,
  `sms` varchar(45) DEFAULT NULL,
  `giga` varchar(45) DEFAULT NULL,
  `fee_extra_min` varchar(45) DEFAULT NULL,
  `fee_extra_sms` varchar(45) DEFAULT NULL,
  `fee_extra_giga` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (1,'mobile_phone','1000','1000',NULL,'10','10',NULL),(2,'mobile_internet',NULL,NULL,'50',NULL,NULL,'10'),(3,'fixed_internet',NULL,NULL,'100',NULL,NULL,'5'),(4,'fixed_phone','2000',NULL,NULL,'5',NULL,NULL);
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_package`
--

DROP TABLE IF EXISTS `service_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_package` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42424 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_package`
--

LOCK TABLES `service_package` WRITE;
/*!40000 ALTER TABLE `service_package` DISABLE KEYS */;
INSERT INTO `service_package` VALUES (1,'all_inclusive'),(2,'business'),(3,'family'),(4,'basic'),(5,'professional');
/*!40000 ALTER TABLE `service_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_package_optional`
--

DROP TABLE IF EXISTS `service_package_optional`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_package_optional` (
  `id_service_package` int NOT NULL,
  `id_optional` int NOT NULL,
  PRIMARY KEY (`id_service_package`,`id_optional`),
  KEY `fk_optional_service_package_idx` (`id_service_package`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_package_optional`
--

LOCK TABLES `service_package_optional` WRITE;
/*!40000 ALTER TABLE `service_package_optional` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_package_optional` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_package_service`
--

DROP TABLE IF EXISTS `service_package_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_package_service` (
  `id_service_package` int NOT NULL,
  `id_service` int NOT NULL,
  PRIMARY KEY (`id_service_package`,`id_service`),
  KEY `fk_service_package_service_idx` (`id_service`),
  CONSTRAINT `fk_service_package_service` FOREIGN KEY (`id_service`) REFERENCES `service` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `fk_service_service_package` FOREIGN KEY (`id_service_package`) REFERENCES `service_package` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_package_service`
--

LOCK TABLES `service_package_service` WRITE;
/*!40000 ALTER TABLE `service_package_service` DISABLE KEYS */;
INSERT INTO `service_package_service` VALUES (1,1),(3,1),(4,1),(1,2),(2,2),(1,3),(3,3),(2,4);
/*!40000 ALTER TABLE `service_package_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validity_period`
--

DROP TABLE IF EXISTS `validity_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validity_period` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_service_package` int NOT NULL,
  `price` int NOT NULL,
  `months` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_validity_period_service_package_idx` (`id_service_package`),
  CONSTRAINT `fk_validity_period_service_package` FOREIGN KEY (`id_service_package`) REFERENCES `service_package` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validity_period`
--

LOCK TABLES `validity_period` WRITE;
/*!40000 ALTER TABLE `validity_period` DISABLE KEYS */;
INSERT INTO `validity_period` VALUES (1,1,20,12),(2,1,18,24),(3,1,15,32),(4,2,18,8),(5,2,15,20),(6,2,13,28),(7,3,15,12),(8,3,13,24),(9,3,10,36),(10,4,13,12),(11,4,10,22),(12,4,8,40);
/*!40000 ALTER TABLE `validity_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_tlc_project'
--

--
-- Dumping routines for database 'db_tlc_project'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-24 23:58:15
